﻿using System.ComponentModel;

namespace LinqPractice
{
    public class Product
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
        public float UnitPrice { get; set; }
        public string Category { get; set; }
        public float  UnitsInStock { get; set; }
    }
    public class Order
    {
        public int OrderId { get; set; }
        public string OrderName { get; set; }
        public int OrderDate { get; set; }
        public float Average { get; set; }
        public float Total { get; set; }

        public int customerId { get; set; }

        public Customer Customer { get; set; }
    }
    public class Customer
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string CustomerPhone { get; set; }
        public string Country { get; set; }
        public string City { get; set; }
        public string Region { get; set; }

        public List<Order> Orders { get; set; }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Product> products = new List<Product>()
            {
                new Product{ProductId=1,Name="AAAAA",Category="Beverages",UnitPrice=100,UnitsInStock=100 },
                new Product{ProductId=2,Name="BBB",Category="Fruits",UnitPrice=2000,UnitsInStock=200 },
                new Product{ProductId=3,Name="CCC",Category="Vegetables",UnitPrice=3000,UnitsInStock=300 },
                new Product{ProductId=4,Name="DDD",Category="AAAA",UnitPrice=4000,UnitsInStock=400 },
                new Product{ProductId=5,Name="EEE",Category="MMMMM",UnitPrice=5000,UnitsInStock=500 }

            };

            List<Order> orders = new List<Order>()
            {
                new Order{ OrderId=1,OrderName="AA",OrderDate=2005,Average=20,Total=100,customerId=1,Customer = new Customer{ } },
                new Order{ OrderId=2,OrderName="BB",OrderDate=2005,Average=20,Total=100,customerId=2,Customer = new Customer{ } },
                new Order{ OrderId=3,OrderName="CC",OrderDate=2005,Average=20,Total=100,customerId=3,Customer = new Customer{ } },
                new Order{ OrderId=4,OrderName="DD",OrderDate=2005,Average=20,Total=100,customerId=4,Customer = new Customer{ } },
                new Order{ OrderId=5,OrderName="EE",OrderDate=2005,Average=20,Total=100,customerId=5,Customer = new Customer{ } }
            };
            List<Customer> customers = new List<Customer>()
            { 
               new Customer {CustomerId=1,CustomerName="MMM",Country="Denmark",City="AA",Region="A",CustomerPhone="123456",Orders = new List<Order>{ new Order { OrderDate=2005,Total=500} } },
               new Customer {CustomerId=2,CustomerName="NNN",Country="UK",City="AA",Region="A",CustomerPhone="123457",Orders = new List<Order>{ new Order {  } } },
               new Customer {CustomerId=3,CustomerName="OOO",Country="Denmark",City="BB",Region="A",CustomerPhone="123458",Orders = new List<Order>{ new Order {  } } },
               new Customer {CustomerId=4,CustomerName="PPP",Country="BB",City="AA",Region="A",CustomerPhone="123459",Orders = new List<Order>{ new Order {  } } },
               new Customer {CustomerId=5,CustomerName="RRR",Country="CC",City="CC",Region="A",CustomerPhone="123450",Orders = new List<Order>{ new Order { OrderDate=2005,Total=500} } },
             };

            //Where

            //var res = products.Where(x => x.UnitPrice > 100);

            //var res1  = from p in products where p.UnitPrice > 100 select p;

            //select

            //var res = products.Select(p => p.Name).ToList();
            //var res1 = from p in products select p.Name;

            //var res = products.Where(p => p.UnitPrice > 100)
            //          .Select(p => new { p.Name,p.UnitPrice}).ToList();


            //SelectMany

            //var res = customers.Where(c => c.Country == "Denmark").SelectMany(c => orders.Where(o => o.customerId == c.CustomerId)).ToList();

            //var res = from c in customers
            //          where c.Country == "Denmark"
            //          from o in orders
            //          where o.customerId == c.CustomerId
            //          select new
            //          {
            //              CustomerId = c.CustomerId,
            //              OrderName = o.OrderName
            //          };

            //Take

            // var res = products.OrderByDescending(p => p.Name).Take(4);

            //skip
            //var res = products.OrderByDescending(p => p.Name).Skip(4);

            //Join
            // var res = customers.Join(orders, c => c.CustomerId, o => o.customerId, (c, o) => new { c.CustomerName, o.OrderDate, o.Total });

            //var res = from c in customers
            //          join o in orders on
            //          c.CustomerId equals o.customerId
            //          select new
            //          {
            //              c.CustomerName,
            //              o.OrderDate,
            //              o.Total
            //          };

            //GroupJoin
            // var res = customers.GroupJoin(orders, c => c.CustomerId, o => o.customerId, (c, co) => new { c.CustomerName, totalOrders = co.Sum(o => o.Total) });

            //var res = from c in customers
            //          join o in orders on
            //          c.CustomerId equals o.customerId into co
            //          select new
            //          {
            //              c.CustomerName,
            //              TotalOrders = co.Sum(o => o.Total)
            //          };

            //var res = from c in customers
            //          join o in orders on
            //          c.CustomerId equals o.customerId into co
            //          from t in co
            //          select new
            //          {
            //              c.CustomerName,
            //             t.OrderDate,
            //             t.Total
            //          };

            //var res = from c in customers
            //          join o in orders on
            //          c.CustomerId equals o.customerId into co
            //          from t in co.DefaultIfEmpty() 
            //          select new
            //          {
            //              c.CustomerName,
            //              t.OrderDate,
            //              t.Total
            //          };


            //concat

            //var res= customers.Select(c=>c.Country).Concat(customers.Select(c=>c.Region)).Concat(customers.Select(c=>c.City)).Distinct().ToList();

            //Orderby/Then By
            // var res= products.OrderBy(p=>p.Category).ThenByDescending(p=>p.UnitPrice).ThenBy(p=>p.Name).ToList();

            //var res = from p in products
            //          orderby
            //          p.Category, p.UnitPrice descending, p.Name
            //          select p;


            //AsEnumerable

            //var res = customers.ToList();

            //var Query = res.AsEnumerable().Where(c => c.CustomerId == 1);


            //ToList

            //  var res= customers.Where(c=>c.Orders.Any(c=>c.OrderDate==2005)).ToList();

            //ToDictionary

            //  var res = customers.SelectMany(c => c.Orders).Where(o => o.OrderDate == 2005).ToDictionary(od => od.OrderId);

            //ToLookUp

            //var res = products.ToLookup(p => p.Category);
            //var result = res["Beverages"];


            //OfType
            //var result = orders.ToList();

            //var res = result.OfType<Order>().Where(o => o.OrderDate == 2005);

            //cast

            //var result = orders.ToList();

            //var res = result.Cast<Order>().Where(o => o.OrderDate == 2005);

            //First  and FirstOrDefault

            // string phno = "123456";

            //var res = customers.First(x => x.CustomerPhone == phno);

            //  var res1 = customers.FirstOrDefault(x => x.CustomerPhone == "");

            //Single and SingleOrDefault

            // int id = 10;
            // var res = customers.Single(c => c.CustomerId == id);

            //var res1 = customers.SingleOrDefault(c => c.CustomerId == id);

            //ElementAt

            //var res = products.OrderByDescending(p => p.UnitPrice).ElementAt(2);


            //Range
            //  var res= Enumerable.Range(0,100).Select(x => x * x).ToArray();

            //Repeat
            //  var res = Enumerable.Repeat(-1L,100).ToArray();


            //Empty
            // var res = Enumerable.Empty<Customer>();

            //Any
            //  bool result = products.Any(p => p.UnitPrice > 100 && p.UnitsInStock > 0);

            //All
            //  bool res = products.All(p=>p.UnitsInStock > 0 );

            //count
            // var res = customers.Count(c => c.Country == "Denmark");

            //sum 

            //  var res = customers.Select(c => new { c.CustomerName, totalOrders = c.Orders.Where(o => o.OrderDate == 2005).Sum(o => o.Total) });

            //Min 

            //var res = products.GroupBy(p => p.Category).Select(g => new { category = g.Key, MinPrice = g.Min(p => p.UnitPrice) });

            //max 
            //var res = customers.SelectMany(c=>c.Orders).Where(o=>o.OrderDate==2005).Max(o=>o.Total);

            //Average

            var res = customers.Select(c => new { c.CustomerName, Average = c.Orders.Average(o => o.Total) });

            Console.Read();

        }
    }
}
