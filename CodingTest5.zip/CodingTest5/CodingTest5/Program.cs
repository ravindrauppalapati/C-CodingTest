﻿namespace CodingTest5
{
    internal class Program
    {   // Right Angle Triangle
        static void Main(string[] args)
        {
            //Console.WriteLine("Enter Number of Rows : ");
            //int num = int.Parse(Console.ReadLine());

            //for (int i = 0; i <  num; i++)
            //{
            //    for (int j = 0; j <= i; j++)
            //    {
            //        Console.Write("*");
            //    }
            //    Console.WriteLine("\n");
            //}
            //============================================
            //######## Mirrored Right Angle

            //Console.WriteLine("Enter Number of Rows : ");
            //int num = int.Parse(Console.ReadLine());

            //for (int i = 0; i <=num; i++)
            //{
            //    for (int j = num - 1; j >= i; j--)
            //    {
            //        Console.Write(" ");
            //    }

            //    for (int k = 1; k <= i; k++)
            //    {
            //        Console.Write("*");
            //    }
            //    Console.WriteLine("\n");
            //}
            //-------------------------------------------------------
            //####### Downwards 
            //Console.WriteLine("Enter Number of Rows : ");
            //int num = int.Parse(Console.ReadLine());
            //for (int i = num - 1; i >= 0; i--) 
            //{
            //    for (int j = 0; j <= i; j++)
            //    {
            //        Console.Write("*");
            //    }
            //    Console.WriteLine("\n");
            //}
            //=====================================
            //####### Downwards Mirrored
            //Console.WriteLine("Enter Number of Rows : ");
            //int num = int.Parse(Console.ReadLine());
            //for (int i = 0; i < num; i++)
            //{
            //    int j = 0;
            //    for (j = 0; j < i; j++)
            //    {
            //        Console.Write(" ");
            //    }

            //    for (j = 0; j < (num - i); j++)
            //    {
            //        Console.Write("*");
            //    }
            //    Console.WriteLine("\n");
            //}
            //============================

            //####### Hollow Right Angle
            //Console.WriteLine("Enter Number of Rows : ");
            //int num = int.Parse(Console.ReadLine());
            //for (int i = 1; i <= num; i++)
            //{
            //    for (int j = 0; j <= i; j++)
            //    {
            //        if (j == 1 || i == j || i == num)
            //        {
            //            Console.Write("*");
            //        }
            //        else Console.Write(" ");
            //    }
            //    Console.WriteLine("\n");
            //}

            //===========================================
            //###### digit Count
            //Console.WriteLine("Enter Number  : ");
            //int num = int.Parse(Console.ReadLine());
            //int count = 0;
            //while (num > 0)
            //{
            //    num = num / 10;
            //    count++;
            //}

            //Console.WriteLine($"No Of Digits : {count}");
            //======================================================
            //###### Sum of Even and ODD 
            //Console.WriteLine("Enter Number  : ");
            //int num = int.Parse(Console.ReadLine());
            //int sum = 0;
            ////for (int i = 2; i <= num; i=i+2)
            //for (int i = 1; i <= num; i = i + 2)
            //{
            //    sum = sum + i;
            //}
            //Console.WriteLine($"Sum : {sum}");
            //=========================================================
            Console.WriteLine("Enter Number  : ");
            int num = int.Parse(Console.ReadLine());
            int factor;
            for (factor =1;factor<=num;factor++) 
            {
                if (num % factor == 0)
                {
                    Console.WriteLine(factor+",");
                }

            }
            Console.Read();
        }
    }
}
