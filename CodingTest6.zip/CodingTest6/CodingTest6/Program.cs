﻿namespace CodingTest6
{
    internal class Program
    {
        static void Main(string[] args)
        {    // 2 D to 1 D , Column and Row Wise
             //int[,] int2DArray = new int[2,3];
             //Console.WriteLine("Enter 2 D Array Elements : ");
             //for (int i = 0; i < 2; i++)
             //{
             //    for (int j = 0; j < 3; j++)
             //    {
             //        int2DArray[i, j] = Convert.ToInt32(Console.ReadLine()); 
             //    }
             //}

            //int index = 0;
            //int noOfRows= int2DArray.GetLength(0);
            //int noOfColumns = int2DArray.GetLength(1);
            //int[] oneDArray = new int[noOfRows * noOfColumns];

            //for (int i = 0; i < noOfColumns  ; i++)
            //{
            //    for (int j = 0; j < noOfRows; j++)
            //    {
            //        oneDArray[index]= int2DArray[j, i];
            //        index++;
            //    }
            //}
            //--------------------------------------------
            //for (int i = 0; i < noOfRows ; i++)
            //{
            //    for (int j = 0; j < noOfColumns; j++)
            //    {
            //        oneDArray[index] = int2DArray[i, j];
            //        index++;
            //    }
            //}
            //Console.WriteLine("1 D Array Elements are :");
            //foreach(int item in oneDArray)
            //    Console.Write(item +" ");

            //====================================================================================
            //1 D to 2D 
            //Console.WriteLine("Enter Number of Rows : ");
            //int rows = int.Parse(Console.ReadLine());
            //Console.WriteLine("Enter Number of Columns : ");
            //int columns = int.Parse(Console.ReadLine());
            //int[] oneDArray = new int[rows * columns];

            //Console.WriteLine("Enter 1 D Array Elements : ");
            //for (int i = 0; i < oneDArray.Length; i++)
            //{
            //    oneDArray[i] = int.Parse(Console.ReadLine());

            //}
            //int index = 0;
            //int [,] twoDArray = new int [rows , columns];

            //for (int i = 0; i < rows; i++)
            //{
            //    for (int j = 0; j < columns; j++)
            //    {
            //        twoDArray[i, j] = oneDArray[index];
            //        index++;
            //    }
            //}

            //Console.WriteLine("2 D Array Elements Are : \n");

            //for (int i = 0; i < rows; i++)
            //{
            //    for (int j = 0; j < columns; j++)
            //    {
            //        Console.Write(twoDArray[i,j]+",");
            //    }
            //    Console.Write("\n");
            //}
            //================================================================
            // Left Rotation of an Array
            //int[] oneDArray = new int[6];
            //Console.WriteLine("Enter Array Elements : ");
            //for (int i = 0; i < oneDArray.Length; i++)
            //{
            //    oneDArray[i] = int.Parse(Console.ReadLine());

            //}
            //int temp = oneDArray[0];

            //for (int i = 0; i < oneDArray.Length - 1; i++)
            //{
            //    oneDArray[i]=oneDArray[i+1];
            //}
            //oneDArray[oneDArray.Length - 1]= temp;
            //----------------------------------
            //int temp = oneDArray[oneDArray.Length - 1];
            //for (int i = oneDArray.Length - 1; i > 0; i--)
            //{
            //    oneDArray[i] = oneDArray[i-1];
            //}
            //oneDArray[0]=temp;
            //Console.WriteLine("Array Elements are : ");
            //foreach (int item in oneDArray)
            //      Console.Write(item +" ");
            //===============================================================
            // Bubble sort

            //int count = 0;
            //int[] oneDArray = new int[5];
            //Console.WriteLine("Enter Array Elements : ");
            //for (int i = 0; i < oneDArray.Length; i++)
            //{
            //    oneDArray[i] = int.Parse(Console.ReadLine());

            //}

            //for (int i = 0; i <= oneDArray.Length - 2; i++)
            //{
            //    for (int j = 0; j <= oneDArray.Length - 2; j++)
            //    {
            //        count++;
            //        if (oneDArray[j] > oneDArray[j + 1])
            //        {
            //            int temp = oneDArray[j + 1];
            //            oneDArray[j+1] = oneDArray[j];
            //            oneDArray[j] = temp;
            //        }
            //    }
            //}

            //Console.WriteLine("Sorting Elements are : ");
            //foreach (int item in oneDArray)
            //{
            //    Console.Write(item+",");
            //}
            //Console.WriteLine();
            //Console.WriteLine("Iterations : "+count);
            //Console.ReadLine();
            //==========================================
            int count = 0;
            int[] intArray = new int[5];
            Console.WriteLine("Enter the Array Elements : ");
            for (int i = 0; i < intArray.Length; i++)
            {
                intArray[i] = int.Parse(Console.ReadLine());
            }
            bool flag = true;
            for (int i = 1; (i <= (intArray.Length - 1)) && flag; i++)
            {
                flag = false;
                for (int j = 0; j < (intArray.Length - 1); j++)
                {
                    count = count + 1;
                    if (intArray[j + 1] > intArray[j])
                    {
                        int temp = intArray[j];
                        intArray[j] = intArray[j + 1];
                        intArray[j + 1] = temp;
                        flag = true;
                    }
                }
            }
            Console.WriteLine("After Sorting Array :");
            foreach (int item in intArray)
            {
                Console.Write(item + " ");
            }
            Console.WriteLine();
            Console.WriteLine("The Loop iterates :" + count);
            Console.ReadKey();
        }
    }
}
