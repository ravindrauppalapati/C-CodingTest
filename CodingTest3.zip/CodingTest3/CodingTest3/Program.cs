﻿using System.Globalization;
using System.Text;

namespace CodingTest3
{
    internal class Program
    {

        static void Main(string[] args)
        {
            //######## Character Occurence
            //Console.WriteLine("Enter string");
            //string str = Console.ReadLine();
            //str = str.Replace(" ",string.Empty);
            //while (str.Length > 0)
            //{
            //    Console.Write(str[0]+":");
            //    int count = 0;
            //    for (int i = 0; i < str.Length; i++)
            //    {
            //        if (str[0] == str[i])
            //        {
            //            count++;
            //        }
            //    }

            //    Console.Write(count+"\n");
            //    str = str.Replace(str[0].ToString(), string.Empty);
            //}
            //----------------------------------------
            //Dictionary<char,int> dict = new Dictionary<char,int>();

            //foreach (char ch in str.Replace(" ", string.Empty))
            //{
            //    if (dict.ContainsKey(ch))
            //        dict[ch] = dict[ch] + 1;
            //    else 
            //        dict.Add(ch, 1);
            //}

            //foreach (var item in dict.Keys) 
            //{
            //    Console.WriteLine($"{item} :{dict[item]}" );
            //}
            //-------------------------------------------
            //Dictionary<char, int> dict = str.Replace(" ", string.Empty).GroupBy(c => c).ToDictionary(d => d.Key, d => d.Count());

            //foreach (var item in dict.Keys)
            //{
            //    Console.WriteLine($"{item} :{dict[item]}");
            //}
            //=========================================================================
            //################# Reverse Each word in a string
            //Console.WriteLine("Enter string");
            //string str = Console.ReadLine();
            //StringBuilder sb = new StringBuilder();
            //List<char> charlist = new List<char>();

            //for (int i = 0; i < str.Length; i++)
            //{
            //    if (str[i] == ' ' || i == str.Length - 1)
            //    {
            //        if (i == str.Length - 1)
            //        {
            //            charlist.Add(str[i]);
            //        }

            //        for (int j = charlist.Count - 1; j >= 0; j--)
            //        {
            //            sb.Append(charlist[j]);
            //        }

            //        sb.Append(' ');
            //        charlist = new List<char>();

            //    }
            //    else charlist.Add(str[i]);


            //}
            //Console.WriteLine($"Reverse Word String :{sb.ToString()}");
            //-----------------------------------------------------------
            //Stack<char> charstack = new Stack<char>();
            //for (int i = 0; i < str.Length; i++)
            //{
            //    if (str[i] != ' ')
            //    {
            //        charstack.Push(str[i]);
            //    }
            //    else
            //    {
            //        while (charstack.Count > 0) {
            //         Console.Write(charstack.Pop()); 
            //        }
            //        Console.Write(' ');
            //    }
            //}
            //while (charstack.Count > 0)
            //{
            //    Console.Write(charstack.Pop());
            //}
            //--------------------------------------------------

            //string st = string.Join(" ", str.Split(' ').Select(x => new string(x.Reverse().ToArray())));
            //Console.Write(st);
            //==========================================================================================
            //############# Remove Duplicates from  string
            //Console.WriteLine("Enter string");
            //string str = Console.ReadLine();
            //string result = string.Empty;
            //for (int i = 0; i < str.Length; i++)
            //{
            //    if (!result.Contains(str[i]))
            //    {
            //        result = result + str[i];
            //    }
            //}
            //Console.Write(result);
            //----------------------------------
            //var RemoveDup = new HashSet<char>(str);
            //foreach (char c in RemoveDup)
            //{
            //    result += c;
            //}
            //Console.Write(result);
            //--------------------------------------
            //var removeDup = str.ToCharArray().Distinct().ToArray();
            //result = new string(removeDup);
            //Console.Write(removeDup);
            //===============================================================================
            //## Find Substring in a String

            //Console.WriteLine("Enter string");
            //string str = Console.ReadLine();
            //int len = str.Length;
            //int temp = 0;
            // Console.WriteLine("All SubStrings : ");

            //for (int i = 0; i < str.Length; ++i)
            //{
            //    StringBuilder sb = new StringBuilder(str.Length - i);
            //    for (int j = i; j < str.Length; ++j)
            //    {
            //        sb.Append(str[j]);
            //        Console.Write(sb + " ");
            //    }
            //}
            //----------------------------------------
            //int len = str.Length;
            //for (int i = 0; i < len; i++)
            //{
            //    for (int j = 0; j < len - i; j++)
            //    {
            //        Console.Write(str.Substring(i,j+1)+" ");
            //    }
            //}
            //---------------------------------------------
            //string[] strArray = new string[len*(len+1)/2];

            //for (int i = 0; i < len; i++)
            //{
            //    for (int j = 0; j < len - i; j++) {
            //        strArray[temp] = str.Substring(i,j+1);
            //        temp++;
            //    }
            //}
            //strArray = strArray.Distinct().ToArray();
            //Console.WriteLine("All SubStrings : ");

            //for (int i = 0; i < strArray.Length; i++)
            //{
            //    Console.Write(strArray[i]+ " ");
            //}
            //----------------------------------------------------------
            //var substr = from i in Enumerable.Range(0, len)
            //             from j in Enumerable.Range(0, len-i+1)
            //             where j >= 1
            //             select str.Substring(i, j);
            //Console.WriteLine( );
            //Console.WriteLine("All SubStrings : ");
            //foreach (var i in substr) {
            //    Console.Write(i + " ");
            //}
            //Console.WriteLine();
            //Console.WriteLine("All  Unique SubStrings : ");
            //foreach (var i in substr.Distinct())
            //{
            //    Console.Write(i + " ");
            //}
            //==========================================================
            //### Remove Duplicates from an Array
            int i = 0, j = 0;
            int[] arr = { 7,7,8,8,9,1,1,4,2,2 };
            for (i = 0; i < arr.Length; i++)
            {
                for (  j = 0; j < arr.Length; j++)
                {
                    if (i == j)
                        continue;
                    if (arr[i] == arr[j])
                        break;
                }

                if(arr.Length == j)
                    Console.WriteLine(arr[i]+" ");
            }
            Console.Read();
        }
    }
}
