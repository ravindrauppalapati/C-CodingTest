﻿namespace CodingTest7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //#################### Find Index of Max Number in an Array#############################
            // float[] array = new float[] { 12,34,56,98,45,23};
            // var maxIndex = array.Select((x, i) => new { value = x, Index = i }).OrderByDescending(x => x.value).Select(x => x.Index).FirstOrDefault();
            //----------------------------------------------------------
            //var maxIndex = Array.IndexOf(array, array.Max());
            //----------------------------------------------------------
            //float max    = 0;
            //float maxIndex = 1;
            //int index = 0;
            //foreach (var num in array)
            //{
            //    if ((num > max) || (maxIndex < 0))
            //    {
            //        maxIndex = index;
            //        max = num;
            //    }
            //    ++index;

            //}
            // Console.WriteLine(maxIndex);
            //======================================================================================
            //################# Find Min and Max element in an Array ########################
            //int[] array = new int[] { 12,56,89,65,36,45,23};
            //int max= array[0];
            //int min= array[0];

            //for (int i = 0; i < array.Length; i++)
            //{
            //    if (array[i] < min)
            //    {
            //        min = array[i];
            //    }

            //    if (array[i] > max)
            //    {
            //        max = array[i];
            //    }
            //}
            //Console.WriteLine("Min Value : "+min);
            //Console.WriteLine("Max Value : "+max);
            //========================================================
            //################ Find Second Highest Num in an Array
            //int[] array = new int[] { 12,56,89,65,36,45,23};
            //int max = array[0];
            //int secondmax = array[0];
            //foreach (int i in array)
            //{
            //    if (i > max)
            //    {
            //        secondmax = max;
            //        max = i;
            //    }
            //    else if (i > secondmax)
            //    {
            //        secondmax = i;
            //    }
            //}
            //Console.WriteLine(secondmax);

            //=========================================================
            //############ Smallest gap b/w numbers in an array
            // int[] array = new int[] { 12,56,89,65,36,45,23};
            //Array.Sort(array);

            //int res = array.Skip(1)
            //    .Select((e,e1)=> e - array[e1]).Min();

            //Console.WriteLine(res);
            //--------------------------------------------------------
            //List<int> result = new List<int>();

            //for (int i = 0; i < array.Length; i++)
            //{
            //    if (array[i] != array.Last())
            //    {
            //        int res = array[i + 1] - array[i];
            //        if(res >= 0)
            //        {
            //            result.Add(res);
            //        }
            //        else result.Add(-res);

            //    }
            //}
            //Console.WriteLine(result.Min());
            //========================================================================
            //############ number of Spaces b/w String##############
            string str;
            Console.WriteLine("Enter string : ");
            str= Console.ReadLine();
            Console.WriteLine($"Spaces : {spaceCount(str)}");
            Console.ReadLine();
        }
        public static int spaceCount(string str)
        {
            int count = 0;
            string str2;
            for (int i = 0; i < str.Length; i++)
            {
                str2 = str.Substring(i, 1);
                if(str2 ==" ")
                    count++;
            }

            return count;
        }
    }
}
