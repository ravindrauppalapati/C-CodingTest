﻿namespace CodingTest2
{
    internal class Program
    {  // 371 => 27 + 343 + 1 => 371
        static void Main(string[] args)
        {
            //###### Armstrong Number
            //Console.WriteLine("Enter Number");
            //int num = int.Parse(Console.ReadLine());
            //int temp = num;
            //int i = 0,count=0;
            //int[] digitArray = new int[10];
            //double sum = 0;
            //while (num > 0)
            //{
            //    digitArray[i++] = num % 10;
            //    num = num / 10;
            //    count++; 
            //}

            //for (int j = 0; j < count; j++)
            //{
            //    sum = sum + System.Math.Pow(digitArray[j], count);
            //}
            //if (sum == temp)
            //    Console.WriteLine("Given number is Armstrong");
            //else Console.WriteLine("Given number is not Armstrong");

            //-------------------------------------------------------------
            // Console.WriteLine("Enter Start Number");
            //int startNum = int.Parse(Console.ReadLine());
            //Console.WriteLine("Enter End Number");
            //int endNum = int.Parse(Console.ReadLine());
            //Console.WriteLine($"Armstrong Numbers between range {startNum} and {endNum} ");
            //for (int i = startNum; i <= endNum; i++) 
            //{
            //    if (IsArmstrongNumber(i))
            //        Console.WriteLine($"{i}");
            //}

            //==================================================================
            //############ Factorial
            //4! => 4*3*2*1*0!(1) 

            //Console.WriteLine("Enter Number");
            //int num =int.Parse(Console.ReadLine());
            // int fact = 1;
            //for (int i = 1; i <= num; i++)
            //{
            //    fact = fact * i;
            //}
            //-------------------------------
            //while (num != 1)
            //{
            //    fact = fact * num;
            //    num = num - 1;
            //}
            //------------------------
            //do { fact = fact * num;
            //    num = num - 1;
            //}while(num > 0);
            //-----------------------------

            //long fact = RecFACT(num);
            //Console.WriteLine($"Factorial  :{fact} ");
            //=============================================================
            //########  Sum of Digits
            //Console.WriteLine("Enter Number");
            //int num = int.Parse(Console.ReadLine());

            //int remainder = 0, sum = 0;

            //while (num > 0) { 
            //     remainder=num % 10;
            //    sum += remainder;
            //    num = num / 10;
            //}
            //Console.WriteLine($"Sum : {sum}");
            //-----------------------
            //int sum = SumofDigits(num);
            //Console.WriteLine($"Sum : {sum}");
            //-------------------------------
            //int sum = num.ToString().Select(x => int.Parse(x.ToString())).ToArray().Sum();
            //Console.WriteLine($"Sum : {sum}");
            //=============================================================
            //########### Decimal to Binary
            //Console.WriteLine("Enter Number");
            //int num = int.Parse(Console.ReadLine());
            //int i;
            //int[] numArray = new int[10];
            //for (  i = 0; num > 0; i++)
            //{
            //    numArray[i] = num % 2;
            //    num = num / 2;
            //}
            //Console.WriteLine("Binary Values : ");

            //for (i = i - 1; i >= 0; i--)
            //{
            //    Console.WriteLine(numArray[i]);
            //}
            //---------------------------------------

            //string result = string.Empty;
            //for (int i = 0; num > 0; i++)
            //{
            //    result =num%2 +result;
            //    num = num / 2;
            //}

            //Console.WriteLine(result);
            //==============================================================
            // ########### Binary to Decimal
            Console.WriteLine("Enter Number");
            int num = int.Parse(Console.ReadLine());
            //int decimalValue = 0;
            //int temp = 1;
            //while (num > 0)
            //{
            //    int remainder = num % 10;
            //    num = num / 10;
            //    decimalValue = decimalValue + (remainder * temp);
            //    temp = temp * 2;

            //}
            //Console.WriteLine(decimalValue);
            //-----------------------------------------------------------
            int decimalValue = Convert.ToInt32(num.ToString(), 2);
            Console.WriteLine(decimalValue);
            Console.Read();
        }

        //static int SumofDigits(int num)
        //{
        //    if (num != 0) { 
        //    return (num % 10 + SumofDigits(num /10));
        //    }
        //    else { return 0; }
        //}
        //static long RecFACT(int num)
        //{
        //    if(num == 1)  
        //        return 1;
        //    else return num * RecFACT(num-1);

        //}
        //static bool IsArmstrongNumber(int Number)
        //{
        //    int sum = 0;
        //    int temp = Number;
        //    int reminder = 0;
        //    int length = Number.ToString().Length;
        //    while (Number != 0)
        //    {
        //        reminder = Number % 10;
        //        Number = Number / 10;
        //        sum = sum +(int) System.Math.Pow(reminder, length);
        //    }
        //    if (sum == temp)
        //        return true;
        //    else return false;  
        //}
    }
}
