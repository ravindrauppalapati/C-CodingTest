﻿namespace CodingTest1
{
    internal class Program
    {    
        static void Main(string[] args)
        {   //##########swapping######

            //int a = 10, b = 20, temp = 0;
            //temp= a;
            //a = b;
            //b = temp;

            //a = a * b;//200
            //b = a / b;//10
            //a = a / b;//20

            //a = a + b;//30
            //b = a - b;//10
            //a = a - b;//20

            //string s1 = "Dotnet", s2 = "Tutorial";
            //s1 = s1 + s2;
            //s2= s1.Substring(0, s1.Length - s2.Length);
            //s1 = s1.Substring(s2.Length);

            //Console.WriteLine($"After Swapping a { a } and b {b}");
            //Console.WriteLine($"After Swapping s1 { s1 } and s2 {s2}");

            //======================================================================
            // #############  Fibonacci 0 1 1 2 3 5 8 13 21 ..............

            //F(n) = F(n-1) + F(n-2);

            //int firstNum = 0, secondNum = 1, nextNum = 0, numberOfElements = 0;
            //Console.WriteLine("Enter Number of Elements : ");
            //numberOfElements =int.Parse( Console.ReadLine());

            //if (numberOfElements < 2)
            //{
            //    Console.WriteLine("Please Enter Number GreatherThan 2");
            //}
            //else {
            //    Console.Write(firstNum + " " + secondNum + " ");

            //    for (int i = 2; i < numberOfElements; i++)
            //    {
            //        nextNum=firstNum+secondNum;
            //        Console.Write(nextNum+" ");
            //        firstNum = secondNum;
            //        secondNum=nextNum;
            //    }

            //}

            //================================================================
            //Console.WriteLine("Enter Number : ");
            //int num = int.Parse(Console.ReadLine());
            //FibonacciSeries(0, 1, 1, num);
            //====================================================================
            //########## Prime Number
            //Console.WriteLine("Enter Number");
            //int num = int.Parse(Console.ReadLine());
            //bool isPrime = true;
            //for (int i = 2; i < num / 2; i++)
            //{
            //    if (num % 2 == 0)
            //    {
            //        isPrime = false;
            //        break;
            //    }
            //}

            //if (isPrime)
            //{
            //    Console.WriteLine($"Given Number {num} is Prime");
            //}
            //else
            //{
            //    Console.WriteLine($"Given Number {num} is not Prime");
            //}
            //======================================================================
            //Console.WriteLine("Enter Starting Number");
            //int startNum = int.Parse(Console.ReadLine());
            //Console.WriteLine("Enter End Number");
            //int endNum = int.Parse(Console.ReadLine());
            //Console.WriteLine($"Prime Numbers Between {startNum} and {endNum}");

            //for (int i = startNum; i < endNum; i++)
            //{
            //    int counter = 0;
            //    for (int j = 2; j < i / 2; j++)
            //    {
            //        if (i % j == 0)
            //        {
            //            counter++;
            //            break;
            //        }
            //    }

            //    if (counter == 0 && i != 1)
            //    {
            //        Console.WriteLine($"{i}");
            //    }

            //}

            // ================================================================

            //########Palindrome
            //Console.WriteLine("Enter Number");
            //int num = int.Parse(Console.ReadLine());

            //int remainder, sum = 0;
            //int temp = num;

            //while (num > 0)
            //{
            //    remainder = num % 10;

            //    sum = (sum*10)+ remainder;

            //    num = num / 10;
            //}

            //if (temp == sum)
            //{
            //    Console.WriteLine($"Given Number {temp} is Palindrome");
            //}
            //else
            //{
            //    Console.WriteLine($"Given Number {temp} is not Palindrome");
            //}
            //==================================================================
            Console.WriteLine("Enter String");
            string name = Console.ReadLine();
            // string reverseString = string.Empty;

            //for (int i = name.Length - 1; i >= 0; i--)
            //{
            //    reverseString += name[i];
            //}

            //if (name == reverseString)
            //    Console.WriteLine($"Given string {name} is Palindrome");
            //else Console.WriteLine($"Given string {name} is not Palindrome");
            //------------------------------
            //foreach (char c in name)
            //{
            //    reverseString = c + reverseString;
            //}
            //if(name.Equals(reverseString, StringComparison.OrdinalIgnoreCase))
            //    Console.WriteLine($"Given string {name} is Palindrome");
            //else Console.WriteLine($"Given string {name} is not Palindrome");
            //------------------------------------------------
            char[] nameArray = name.ToCharArray();
            Array.Reverse(nameArray);

            string reverse = new string(nameArray);
            if (name.Equals(reverse , StringComparison.OrdinalIgnoreCase))
                Console.WriteLine($"Given string {name} is Palindrome");
             else Console.WriteLine($"Given string {name} is not Palindrome");
            Console.ReadLine();
        }

        //public static void FibonacciSeries(int firstNum, int secondNum, int Counter, int number)
        //{
        //    Console.WriteLine(firstNum+" ");
        //    if (Counter < number)
        //    {
        //        FibonacciSeries(secondNum,firstNum+secondNum,Counter+1,number);
        //    }
        //}
    }
}
