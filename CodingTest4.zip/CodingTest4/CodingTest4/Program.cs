﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace CodingTest4
{
    internal class Program
    {
        //Duck Number
        // 10,20,2002,*0212*
        static void Main(string[] args)
        {
            //    Console.WriteLine("Enter Number : ");
            //    int num = int.Parse(Console.ReadLine());

            //    string str = num.ToString();

            //    int l = str.Length;

            //    int temp = 0;
            //    char ch;

            //    for (int i = 0; i < l; i++)
            //    {
            //        ch = str[i];
            //        if(ch == '0')
            //        {
            //            temp++;
            //            break;
            //        }
            //    }

            //    char ctr = str[0];
            //    if (temp > 0 && (ctr == '0' || ctr != '0'))
            //    {
            //        Console.WriteLine("Duck Number");
            //    }
            //    else Console.WriteLine("Not Duck Number");
            //-----------------------------------------------------------------------
            //int dno, dkno, r, flg=0;
            //Console.WriteLine("The Duck Numbers Between 1 to 100 are : ");

            //for (dkno = 1; dkno <= 200; dkno++)
            //{
            //    dno = dkno;
            //    flg = 0;
            //  //  2002
            //    while (dno > 0)
            //    {
            //        if (dno % 10 == 0)
            //        {
            //            flg = 1;
            //            break;
            //        }
            //        dno/= 10;
            //    }
            //    if (dkno > 0 && flg == 1)
            //    {
            //        Console.WriteLine(dkno);
            //    }
            //}
            //========================================
            //#####Disarium Number   175 => 1 + 7*7 + 5*5*5 = 175 (1 + 49 + 125)

            //Console.WriteLine("Enter Number : ");
            //    int num = int.Parse(Console.ReadLine());
            //   string str = num.ToString(); 
            //    int l = str.Length;
            //int div = 0, sum = 0, temp = num;
            //while (temp > 0)
            //{
            //    div = temp % 10;
            //    sum = sum + (int)System.Math.Pow(div,l);
            //    l--;
            //    temp =temp/10;
            //}
            //if(sum == num)
            //{
            //    Console.WriteLine("Disarium Number");
            //}
            //else
            //{
            //    Console.WriteLine("Not Disarium Number");
            //}
            //---------------------------------------------------------------------------
            //int result = 0;
            //Console.WriteLine("Disarium Numbers between 1 to 200 are :  ");

            //for (int i = 1; i <= 200; i++)
            //{
            //    result = SumOfDigits(i);
            //    if(result == i)
            //        Console.WriteLine(i);
            //}
            //==================================================================
            //##### Twisted Prime

            //Console.WriteLine("Enter Number : ");
            //   int num = int.Parse(Console.ReadLine());

            //int reverseNo = reverseNum(num);

            //if (IsPrime(num) && IsPrime(reverseNo))
            //{
            //    Console.WriteLine("Twisted Prime");
            //}
            //else { Console.WriteLine("Not Twisted Prime"); }

            //---------------------------------------------------------------
            //Console.WriteLine("Twisted Primes Between 10 to 100 are : ");

            //for (int i = 1; i < 100; i++)
            //{
            //    int reverseNo = reverseNum(i);

            //    if (IsPrime(i) && IsPrime(reverseNo))
            //    {
            //        Console.WriteLine($"{i} + Twisted Prime");
            //    }
            //    //else { Console.WriteLine($" {i} Not Twisted Prime"); }
            //}
            //=================================================================
            //########  Buzz Number
            //Console.WriteLine("Enter Number : ");
            //int num = int.Parse(Console.ReadLine());
            //if (num % 10 == 7 || num % 7 == 0)
            //{
            //    Console.WriteLine("Buzz Number");
            //}
            //else Console.WriteLine("Not Buzz Number");
            //-----------------------------------------------------------------------------------
            //Console.WriteLine("Buzz Numbers Between 1 to 100 are : ");
            //for (int i = 1; i < 100; i++)
            //{
            //    if (i % 10 == 7 || i % 7 == 0)
            //    {
            //        Console.WriteLine($"{i} Buzz Number");
            //    }

            //}
            //==============================================
            //###### Strong Number  145 => 1! + 4! + 5! = 145
            //Console.WriteLine("Enter Number : ");
            //int num = int.Parse(Console.ReadLine());
            //int temp = num, sum = 0, rem = 0,div=0;
            //while (temp != 0)
            //{
            //    rem = temp % 10;
            //    int fact = calculateFact(rem);
            //    temp = temp / 10;
            //    sum = sum + fact;
            //}
            //if (sum == num) { Console.WriteLine("Strong NUmber"); }
            //else
            //{
            //    Console.WriteLine("Not Strong Number");
            //}
            //-----------------------------------------------------------
            Console.WriteLine("Enter Number : ");
            int num = int.Parse(Console.ReadLine());
            int rem = 0;
            Console.WriteLine($"Strong Numbers between 1 to {num} are : ");
            for (int i = 1; i <= num; i++)
            {
                int temp = i,sum = 0;
                while (temp != 0)
                {
                    rem = temp % 10;
                    int fact = calculateFact(rem);
                    temp = temp / 10;
                    sum = sum + fact;
                }
                if (sum == i)
                {
                    Console.WriteLine(i);
                }

            }
            Console.ReadKey();
        }
        public static int calculateFact(int num)
        {
            int fact = 1;
            for (int i = 1; i <= num; i++)
            {
                fact =fact * i;
            }
            return fact;
        }
        //public static int reverseNum(int num)
        //{
        //    int revno = 0;
        //    while (num > 0)
        //    {
        //        revno = revno * 10 + num % 10;
        //        num /= 10;
        //    }
        //    return revno;
        //}
        //public static bool IsPrime(int Num)
        //{
        //    bool isPrimeNum = true;
        //    for (int i = 2; i <= Num/2; i++)
        //    {
        //        if (Num % i == 0) 
        //        { 
        //            isPrimeNum = false; 
        //            break;
        //        }
        //    }
        //    return isPrimeNum;
        //}
        //public static int SumOfDigits(int num)
        //{
        //    int sum = 0, rem = 0;
        //    int len = CalculateLength(num);
        //    while (num > 0)
        //    {
        //        rem = num % 10;
        //        sum = sum + (int)System.Math.Pow(rem, len);
        //        num = num / 10;
        //        len--;
        //    }
        //    return sum;
        //}
        //public static int CalculateLength(int number)
        //{
        //    int lng = 0;
        //    while (number != 0) {
        //        lng = lng + 1;
        //        number = number / 10;
        //    }
        //    return lng;
        //}
    }
}
